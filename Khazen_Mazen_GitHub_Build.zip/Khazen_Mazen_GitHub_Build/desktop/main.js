const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');

function backupDirectory() {
  return path.join(app.getPath('userData'), 'Backups');
}

ipcMain.handle('save-local-backup', async (_event, json) => {
  if (typeof json !== 'string' || json.length > 100 * 1024 * 1024) {
    throw new Error('Invalid backup data');
  }
  const dir = backupDirectory();
  fs.mkdirSync(dir, { recursive: true });
  const target = path.join(dir, 'Khazen-Mazen-Auto-Backup.json');
  const temp = target + '.tmp';
  fs.writeFileSync(temp, json, 'utf8');
  fs.renameSync(temp, target);
  return true;
});

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 900,
    minHeight: 650,
    title: 'خازن مازن',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.loadFile(path.join(__dirname, '..', 'www', 'index.html'));
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
