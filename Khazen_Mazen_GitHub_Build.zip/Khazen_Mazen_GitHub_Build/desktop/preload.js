const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('mazensoft', {
  saveAutomaticBackup: (json) => ipcRenderer.invoke('save-local-backup', json)
});
