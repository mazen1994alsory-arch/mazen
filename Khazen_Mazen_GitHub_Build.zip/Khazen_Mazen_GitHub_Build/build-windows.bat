@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title إنشاء مثبت خازن مازن

echo ==============================================
echo          خازن مازن - مثبت ويندوز
echo ==============================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo يلزم تثبيت Node.js LTS أولاً من: https://nodejs.org/
  echo بعد التثبيت أعد تشغيل هذا الملف.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo لم يتم العثور على npm. أعد تثبيت Node.js.
  pause
  exit /b 1
)

echo [1/2] تنزيل مكونات البرنامج لأول مرة...
call npm install
if errorlevel 1 goto failed

echo.
echo [2/2] إنشاء ملف التثبيت EXE لويندوز 64-bit...
call npm run build:windows
if errorlevel 1 goto failed

echo.
echo ==============================================
echo تم إنشاء مثبت خازن مازن بنجاح.
echo افتح مجلد release لتجد Khazen-Mazen-Setup-1.0.1.exe
echo ==============================================
explorer "%~dp0release"
pause
exit /b 0

:failed
echo.
echo تعذر إكمال البناء. تحقق من اتصال الإنترنت ثم أعد المحاولة.
echo إذا استمر الخطأ أرسل صورة هذه النافذة.
pause
exit /b 1
